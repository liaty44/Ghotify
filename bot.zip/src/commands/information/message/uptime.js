const { EmbedBuilder } = require("discord.js");
const { timeformat } = require("@helpers/Utils");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "uptime",
  description: "gives you bot uptime",
  category: "UTILITY",
  botPermissions: ["EmbedLinks"],

  command: {
    enabled: true,
  },

  async messageRun(message) {
    const embed = new EmbedBuilder()
      .setColor("#ffd700")
      .setDescription(`**Uptime:** \`${timeformat(process.uptime())}\``);

    await message.channel.send({ embeds: [embed] });
  },
};
