const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { EMBED_COLORS } = require("@root/config");

function avatarInfo(user) {
  const url = user.displayAvatarURL({ extension: "png", size: 512 });

  const embed = new EmbedBuilder()
    .setTitle(`Avatar of ${user.username}`)
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setImage(url)
    .setDescription(`**[\`Download Avatar\`](${url})**`);

  return { embeds: [embed] };
}

module.exports = {
  name: "avatar",
  description: "Displays a user's avatar",

  slashCommand: {
    enabled: true,
    ephemeral: false,
    options: [
      {
        name: "user",
        description: "User to view",
        type: ApplicationCommandOptionType.User,
        required: false,
      },
    ],
  },

  async interactionRun(interaction) {
    const user = interaction.options.getUser("user") || interaction.user;
    return interaction.followUp(avatarInfo(user));
  },
};
