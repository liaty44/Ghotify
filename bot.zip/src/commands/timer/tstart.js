const { ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");
const { activeTimers } = require("@src/commands/timer/timerStore");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "tstart",
  description: "sets a countdown timer with a custom message",
  category: "TIMER",
  userPermissions: [],
  command: {
    enabled: true,
    usage: "<duration> <message>",
    minArgsCount: 2,
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "duration",
        description: "duration of the timer (e.g., 1h, 30m, 2d, 3mo)",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
      {
        name: "message",
        description: "the message for the timer embed title",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },

  async messageRun(message, args) {
    const duration = args[0];
    const customMessage = args.slice(1).join(" ");
    await startTimer(message, duration, customMessage);
  },

  async interactionRun(interaction) {
    const duration = interaction.options.getString("duration");
    const customMessage = interaction.options.getString("message");
    await startTimer(interaction, duration, customMessage);
  },
};

async function startTimer(context, duration, customMessage) {
  const seconds = parseDurationToSeconds(duration);
  if (!seconds || seconds <= 0) {
    return context.channel.send("Please provide a valid duration (e.g., `1h`, `30m`, `2d`, `3mo`).");
  }

  const userId = context.author?.id || context.user?.id;

  const endTimestamp = Math.floor(Date.now() / 1000) + seconds;

  // Build start embed (MATCHES SCREENSHOT)
  const embed = new EmbedBuilder()
    .setTitle(`⏰ Timer`)
    .setColor(0x43e97b)
    .setDescription(
      `${customMessage}\n\n` +
        ` **Ends:** <t:${endTimestamp}:R> (**<t:${endTimestamp}:f>**)\n\n` +
        `**Timer ends — <t:${endTimestamp}:t>**`
    )
    .setTimestamp();

  // Send the embed
  const timerMessage = await context.channel.send({ embeds: [embed] });

  const timeout = setTimeout(async () => {
    // 1️⃣ Real ping
    await context.channel.send(`<@${userId}> your timer has ended!`);

    // 2️⃣ Update original embed to show completed
    const endEmbed = EmbedBuilder.from(embed)
      .setColor(0xff4444)
      .setDescription(
        `⏰ **Timer Finished!**\n\n` +
          `${customMessage}\n\n` +
          `**Ended:** <t:${endTimestamp}:f>\n` +
          `**Timer ended — <t:${endTimestamp}:t>**`
      )
      .setFooter({ text: "Timer Completed" })
      .setTimestamp();

    await timerMessage.edit({ embeds: [endEmbed] });
    activeTimers.delete(timerMessage.id);
  }, seconds * 1000);

  activeTimers.set(timerMessage.id, { timeout, userId, customMessage });
}

function parseDurationToSeconds(duration) {
  const timeRegex = /^(\d+)(s|m|h|d|w|mo)$/i;
  const match = duration.match(timeRegex);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();

  return {
    s: value,
    m: value * 60,
    h: value * 3600,
    d: value * 86400,
    w: value * 604800,
    mo: value * 2592000,
  }[unit];
}
