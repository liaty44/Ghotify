const { EmbedBuilder } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "reload",
  description: "Reload bot commands & events",
  category: "OWNER",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    aliases: ["rl"],
  },

  async messageRun(message) {
    const client = message.client;

    const embed = new EmbedBuilder()
      .setColor(client.config.EMBED_COLORS.BOT_EMBED)
      .setDescription("Reloading bot components...");

    const msg = await message.channel.send({ embeds: [embed] });

    try {
      // Reload commands
      await client.loadCommands();

      // Reload events
      await client.loadEvents();

      // Reload slash (if enabled)
      if (client.config.INTERACTIONS.ENABLED) {
        await client.registerInteractions();
      }

      const done = new EmbedBuilder().setColor("#00ff00").setDescription("✅ **Bot Reloaded Successfully!**");

      return msg.edit({ embeds: [done] });
    } catch (error) {
      const err = new EmbedBuilder()
        .setColor("#ff0000")
        .setDescription(`❌ Reload failed:\n\`\`\`${error.message}\`\`\``);

      return msg.edit({ embeds: [err] });
    }
  },
};
