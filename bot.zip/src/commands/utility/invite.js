const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "invite",
  description: "Get the bot's invite link",
  category: "UTILITY",
  botPermissions: ["EmbedLinks"],

  command: {
    enabled: true,
  },

  async messageRun(message) {
    const client = message.client;

    const inviteURL = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&integration_type=0&scope=bot+applications.commands`;
    const supportURL = "https://discord.gg/codexdev";

    const embed = new EmbedBuilder()
      .setColor("#ffd700")
      .setAuthor({
        name: `${client.user.username} — Invite`,
        iconURL: client.user.displayAvatarURL(),
      })
      .setThumbnail(client.user.displayAvatarURL())
      .setDescription(
        `**Invite ${client.user.username} to your server**\n` +
          `Click the button below to invite the bot.\n\n` +
          `**Invite Link:** [Click here](${inviteURL})`
      )
      .setFooter({
        text: `Requested by ${message.author.username}`,
        iconURL: message.author.displayAvatarURL(),
      });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel("Invite").setStyle(ButtonStyle.Link).setURL(inviteURL),

      new ButtonBuilder().setLabel("Support").setStyle(ButtonStyle.Link).setURL(supportURL)
    );

    return message.channel.send({ embeds: [embed], components: [row] });
  },
};
