const { AttachmentBuilder, ApplicationCommandOptionType } = require("discord.js");
const Canvas = require("@napi-rs/canvas");
const { getMemberStats, getXpLb } = require("@schemas/MemberStats");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "rank",
  description: "displays members rank in this server",
  cooldown: 5,
  category: "STATS",
  botPermissions: ["AttachFiles"],
  command: {
    enabled: true,
    usage: "( mention / id )",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "user",
        description: "target user",
        type: ApplicationCommandOptionType.User,
        required: false,
      },
    ],
  },

  async messageRun(message, args, data) {
    const member = (await message.guild.resolveMember(args[0])) || message.member;
    const buffer = await generateRankCard(message, member, data.settings);
    await message.safeReply({ files: [buffer] });
  },

  async interactionRun(interaction, data) {
    const user = interaction.options.getUser("user") || interaction.user;
    const member = await interaction.guild.members.fetch(user);
    const buffer = await generateRankCard(interaction, member, data.settings);
    await interaction.followUp({ files: [buffer] });
  },
};

async function generateRankCard(context, member, settings) {
  const guild = context.guild;
  const { user } = member;

  if (!settings.stats.enabled) return "Stats tracking is disabled on this server.";

  const stats = await getMemberStats(guild.id, user.id);
  if (!stats?.xp) return `${user.username} is not ranked yet!`;

  // Leaderboard position
  const lb = await getXpLb(guild.id, 100);
  let pos = lb.findIndex((doc) => doc.member_id == user.id) + 1;

  const xpNeeded = stats.level * stats.level * 100;

  // Create canvas
  const width = 1000;
  const height = 300;
  const canvas = Canvas.createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  // Background
  ctx.fillStyle = "#131313";
  roundRect(ctx, 0, 0, width, height, 30);
  ctx.fill();

  // Avatar
  const avatar = await Canvas.loadImage(user.displayAvatarURL({ extension: "png", size: 256 }));

  ctx.save();
  ctx.beginPath();
  ctx.arc(150, 150, 100, 0, Math.PI * 2, true);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(avatar, 50, 50, 200, 200);
  ctx.restore();

  // Username
  ctx.fillStyle = "white";
  ctx.font = "bold 45px Sans";
  ctx.fillText(user.username, 300, 90);

  // Rank & Level
  ctx.font = "35px Sans";
  ctx.fillStyle = "#aaaaaa";
  ctx.fillText(`Rank #${pos}`, 300, 150);
  ctx.fillText(`Level ${stats.level}`, 470, 150);

  // XP Bar Background
  ctx.fillStyle = "#555555";
  roundRect(ctx, 300, 180, 650, 40, 20);
  ctx.fill();

  // XP Bar Fill
  const xpPercent = Math.min(stats.xp / xpNeeded, 1);
  ctx.fillStyle = "#00ff84";
  roundRect(ctx, 300, 180, 650 * xpPercent, 40, 20);
  ctx.fill();

  // XP TEXT — CENTERED + LOWERED
  const xpText = `${stats.xp}/${xpNeeded} XP`;
  ctx.font = "bold 28px Sans";
  ctx.fillStyle = "white";

  const textWidth = ctx.measureText(xpText).width;

  const textX = 300 + 650 / 2 - textWidth / 2; // centered
  const textY = 180 + 40 + 32; // slightly below bar

  ctx.fillText(xpText, textX, textY);

  // RETURN IMG
  const buffer = await canvas.encode("png");
  return new AttachmentBuilder(buffer, { name: "rank.png" });
}

// Rounded rectangle helper
function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}
