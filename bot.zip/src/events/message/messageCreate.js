const { commandHandler, automodHandler, statsHandler } = require("@src/handlers");
const { PREFIX_COMMANDS, OWNER_IDS } = require("@root/config");
const { getSettings } = require("@schemas/Guild");

/**
 * @param {import('@src/structures').BotClient} client
 * @param {import('discord.js').Message} message
 */
module.exports = async (client, message) => {
  if (!message.guild || message.author.bot) return;

  const settings = await getSettings(message.guild);
  const prefix = settings.prefix || PREFIX_COMMANDS.DEFAULT_PREFIX;
  const authorId = message.author.id;
  let isCommand = false;

  // ─────────────────────────────
  // BOT MENTION → SHOW PREFIX
  // ─────────────────────────────
  if (message.content.match(new RegExp(`^<@!?${client.user.id}>$`))) {
    return message.channel.safeSend(`My prefix in this server is: \`${prefix}\``);
  }

  const content = message.content.trim();

  // ─────────────────────────────
  // PREFIX COMMANDS (everyone)
  // ─────────────────────────────
  if (PREFIX_COMMANDS.ENABLED && content.startsWith(prefix)) {
    const args = content.slice(prefix.length).trim().split(/\s+/);
    const invoke = args.shift().toLowerCase();

    const cmd = client.getCommand(invoke);
    if (cmd) {
      isCommand = true;
      return commandHandler.handlePrefixCommand(message, cmd, settings);
    }
  }

  // ─────────────────────────────
  // NO-PREFIX COMMANDS (ONLY OWNER)
  // ─────────────────────────────
  if (PREFIX_COMMANDS.ALLOW_NO_PREFIX && OWNER_IDS.includes(authorId)) {
    const args = content.split(/\s+/);
    const invoke = args.shift().toLowerCase();

    const cmd = client.getCommand(invoke);
    if (cmd) {
      isCommand = true;
      return commandHandler.handlePrefixCommand(message, cmd, settings);
    }
  }

  // ─────────────────────────────
  // STATS TRACKING
  // ─────────────────────────────
  if (settings.stats.enabled) {
    await statsHandler.trackMessageStats(message, isCommand, settings);
  }

  // ─────────────────────────────
  // AUTOMOD ONLY IF NOT COMMAND
  // ─────────────────────────────
  if (!isCommand) {
    await automodHandler.performAutomod(message, settings);
  }
};
