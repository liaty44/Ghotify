const { model, Schema } = require("mongoose");

const NoPrefix = new Schema({
  commands: { type: [String], default: [] },
});

module.exports = model("NoPrefix", NoPrefix);
