const { EmbedBuilder, ApplicationCommandType } = require("discord.js");
const { EMBED_COLORS } = require("@root/config");

function avatarInfo(user) {
  const url = user.displayAvatarURL({ extension: "png", size: 512 });

  return {
    embeds: [
      new EmbedBuilder()
        .setTitle(`Avatar of ${user.username}`)
        .setColor(EMBED_COLORS.BOT_EMBED)
        .setImage(url)
        .setDescription(`**[\`Download Avatar\`](${url})**`),
    ],
  };
}

module.exports = {
  name: "avatar",
  description: "View avatar",
  type: ApplicationCommandType.User,
  enabled: true,
  ephemeral: false,

  async run(interaction) {
    const user = await interaction.client.users.fetch(interaction.targetId);
    return interaction.followUp(avatarInfo(user));
  },
};
